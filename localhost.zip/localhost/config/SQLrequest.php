<?php
 class SQLrequest{
    private static string $_getProducts="select * from products";
    private static string $_getProduct="select * from products where id=?";
    private  static string $_createProducts="insert into products(title,description,price) values(?,?,?)";
    private static string $_updateProduct="update products set title=?, description=?, price=? where id=? ";
    private static string $_deleteProduct="delete from products where id=?";
    public static function getProducts():string{
        return self::$_getProducts;
    }
    public static function getProduct():string{
        return self::$_getProduct;
    }
    public static function createProducts():string{
        return self::$_createProducts;
    }
    public static function updateProduct():string{
        return self::$_updateProduct;
    }
    public static function deleteProduct():string{
        return self::$_deleteProduct;
    }
}