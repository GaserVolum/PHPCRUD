<?php
require_once "SQLrequest.php";
class DBCONNpdo extends SQLrequest{
    public function __construct(){
        $this->dbname="";
        $this->clientname="";
        $this->clientpass="";
        $this->host="";
        
    }
    private string $dbname;
    private string $clientname;
    private string $clientpass;
    private string $host;
     
    public function connect():PDO|bool{
        try{
            echo "<br>DATABASE CONNECTED</br>";
            return new PDO("mysql:host=$this->host;
                                 dbname=$this->dbname;",
                                 $this->clientname,
                                 $this->clientpass);
            
        }
        catch(PDOException $ex){
            echo $ex->getMessage();
            return false;
        }
    }
}


